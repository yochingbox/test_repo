#ifndef _VER_H
#define _VER_H

enum version{
    MAJOR_VER = 2,
    MINOR_VER = 7,
    PATCH_VER = 0,
    BUILD_VER = 0
};

#endif // _VER_H

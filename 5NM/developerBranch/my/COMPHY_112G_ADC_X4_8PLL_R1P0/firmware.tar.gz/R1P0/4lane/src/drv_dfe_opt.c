#include "common.h"
#include "driver.h"

//assume DFE value is postive number
//reg_DFE_OPT_FFE_PST1_MAX_LANE_6_0 is postive value, [6] must be 0. 

void drv_dfe_opt ()
{


}


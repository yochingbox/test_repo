#include "common.h"
#include "driver.h"

void drv_pwr_opt (uint8_t en) {

}

Authors and Contributors
========================


Authors
-------

* Marek Rudnicki <marekrud@posteo.de>
* Joakim Möller <joakim.moller@molflow.com>



Contributors
------------

* Michael Schutte <michael.schutte@tum.de>


                                % Basic MATLAB script


pause(3);

y = x * 2;
